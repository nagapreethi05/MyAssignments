import { book } from './components/book';
type state = {
    books: book[],
    users: any[],
    user: boolean
}
type Action =
    | { type: "ADDBOOK", book: book[] }
    | { type: "DELETE", deleteBook: string }
    | { type: "LIST", books: book[] }
    | { type: "LOGOUT" }
    | { type: "SEARCH", data: string, category: string }
    | { type: "LOGIN", user: { username: string, password: string } }
    | { type: "LOGINWITHOTP", withOtp: { username: string, password: string, otp: string } }
const reducer = (state: state, action: Action): any => {
    switch (action.type) {
        case "LIST":
            state.books = []
            return {
                ...state,
                books: [...state.books.concat(action.books)]
            }
        case "ADDBOOK":
           
            console.log(action.book)
            return {
                ...state,
                books: [...state.books, action.book]
            }
        case "LOGIN":
            return {
                ...state,
                user: true
            }
        case "LOGOUT":
            return {
                ...state,
                user: false
            }
        case "DELETE":
            console.log(action.deleteBook)
            return {
                ...state,
                books: state.books.filter((book) => book.id !== action.deleteBook)
            }
        case "LOGINWITHOTP":
        default:
            return state
    }
}
export default reducer