import React, { useContext, useEffect, useState } from "react"
import UserContext from "./UserContext";
import SimpleModel from './OtpLogIn';

interface Iprops {
    valid?: string,
    // userCheck?: () => void,
    handlelogin: (username: string, password: string) => void
}

const LogIn: React.FC<Iprops> = (props: Iprops) => {

    const [username, setUsername] = useState("");
    const [password, setPassword] = useState("");
    const [valid, setValid] = useState("");
    const [optmodel, setOptmodel] = useState(false);

    // const { actions, dispatch } = useContext(UserContext)

    const handleInput = (e: any) => {
        if (e.target.id === "exampleInputEmail1") {
            setUsername(e.target.value);

        }
        if (e.target.id === "exampleInputPassword1") {
            setPassword(e.target.value);
        }
    }

    const changeSetOtp = () => {
        // setOptmodel(false);
        //props.userCheck();
    }

    const handleLogin = async (username: string, password: string) => {
        setValid("");
        // let res = await actions.logIn(dispatch, username, password);
        props.handlelogin(username, password);
        // if(res.status===200){

        //     //localStorage.setItem("token",mes);
        //     //props.userCheck();
        setOptmodel(true);
        //  }else{
        //     setValid(res + ", check username and password");
        // }
    }

    return (
        <div className="container shadow p-3 mb-9 bg-white rounded">
            {/* <div style={{ margin: "auto", width: "50%", justifyContent: "center" }}> */}
            <br/>
            <h1>Login</h1>
            <p>Please fill in this form to login to your account.</p>
            <hr></hr>

            <form>
                {/* <div style={{ marginTop: "5%" }} className="form-group"> */}
                    {/* <label htmlFor="exampleInputEmail1">Email address</label> */}
                    <label ><b>Email</b></label>
                    <input type="text" placeholder="Enter Email" name="email" id="exampleInputEmail1" required onChange={handleInput}/>

                    {/* <input type="email" className="form-control" id="exampleInputEmail1" placeholder="Enter email" onChange={handleInput} required /> */}
                    <small id="emailHelp" className="form-text text-muted">We'll never share your email with anyone else.</small>
                {/* </div> */}
                {/* <div style={{ marginTop: "5%" }} className="form-group"> */}
                    {/* <label htmlFor="exampleInputPassword1">Password</label> */}
                    <br/>
                    <label ><b>Password</b></label>
                    <input type="password" className="form-control" id="exampleInputPassword1" placeholder="Password" onChange={handleInput} required />
                    {/* <i style={{ marginLeft: "640px" }}><Link to="/forgetpassword" >forget password</Link></i> */}
                {/* </div> */}
                <div style={{ marginTop: "1%" }} className="form-check">
                    <input type="checkbox" className="form-check-input" id="exampleCheck1" required />
                    <label className="form-check-label" htmlFor="exampleCheck1">Accept Terms and Conditions</label>
                </div>
                <button style={{ marginTop: "5%" }} type="button" className="registerbtn" onClick={() => handleLogin(username, password)}>Submit</button>
                {/* <button type="submit" className="registerbtn" onClick={() => handleLogin(username, password)}>Register</button> */}
            </form>
            {valid ? <div style={{ color: "red" }}>{valid}</div> : null}
            {optmodel ? <SimpleModel username={username} password={password} otphandle={() => changeSetOtp()}></SimpleModel> : null}
        </div>
     
    )
}

export default LogIn