import React, { useContext, useEffect, useState } from 'react';
import { makeStyles, Theme, createStyles } from '@material-ui/core/styles';
import Modal from '@material-ui/core/Modal';
import UserContext from './UserContext';
import { useHistory } from 'react-router';

function getModalStyle() {
  const top = 50;
  const left = 50;

  return {
    top: `${top}%`,
    left: `${left}%`,
    transform: `translate(-${top}%, -${left}%)`,
    color: "black",
  };
}

const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    paper: {
      position: 'absolute',
      width: 400,
      backgroundColor: theme.palette.background.paper,
      border: '2px solid #000',
      borderRadius: "5%",
      boxShadow: theme.shadows[5],
      padding: theme.spacing(2, 4, 3),
    },
  }),
);

interface Iprops {
  username: string,
  password: string,
  otphandle: () => void,
}

const SimpleModal: React.FC<Iprops> = (props: Iprops) => {

  const classes = useStyles();
  // getModalStyle is not a pure function, we roll the style only on the first render
  const [modalStyle] = useState(getModalStyle);
  const [open, setOpen] = useState(false);
  const [otp, setOtp] = useState<string>();
  const [submit, setSubmit] = useState(false);
  const [message, setMessage] = useState("");

  //   const {actions, dispatch} = useContext(UserContext);
  const history = useHistory();

  useEffect(() => {
    setOpen(true);
  }, [])

  const handleOpen = () => {
    setOpen(true);
  };

  const handleInput = (e: any) => {
    setOtp(e.target.value)
    setSubmit(true);
  }

  const handleClose = () => {
    setOpen(false);
  };

  const handleSubmit = async () => {
    console.log("handlesubmit")
    //setOpen(false);
    //props.otphandle()
    //   let res = await actions.logInWithOtp(dispatch, props.username, props.password, otp!);
    let otptoken=localStorage.getItem("otptoken");
    let res = await fetch(`http://localhost:9000/api/users/otpverifying`,
      {
        method: "POST",
        body: JSON.stringify({ username: props.username, password: props.password,otp: otp,token:otptoken}),
        headers: { "Content-Type": "application/json" }})
let token=await res.json()
    if (res.status === 200) {
      console.log("status 200")
      localStorage.setItem("token",token);
      setOpen(false);
      props.otphandle()
      history.push("/")
    } else {
      setMessage(res + ", please login again");
    }
  };

  const handleCancel = () => {
    setOpen(false);
    props.otphandle()
  }

  const body = (
    <div style={modalStyle} className={classes.paper}>
      <div style={{ marginTop: "5%" }} className="form-group">
        <label htmlFor="exampleInputEmail1">Enter the OTP sent to the registered phone number.</label>
        <input type="number" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="6 digit OTP" onChange={handleInput} required />
      </div>
      {message ? <div style={{ color: "red" }}>{message}</div> : null}
      <button style={{ marginTop: "5%" }} type="button" className="btn btn-secondary" onClick={() => { handleCancel() }}>Cancel</button>
      {submit ? <button style={{ margin: " 2% 0% 0% 17%" }} type="button" className="btn btn-primary" onClick={() => { handleSubmit() }}>Submit</button> : null}
    </div>
  );

  return (
    <div>
      {/* <button type="button" onClick={handleOpen}>
        Open Modal
      </button> */}
      <Modal
        open={open}
        // onClose={handleClose}
        aria-labelledby="simple-modal-title"
        aria-describedby="simple-modal-description"
      >
        {body}
      </Modal>
    </div>
  );
}

export default SimpleModal