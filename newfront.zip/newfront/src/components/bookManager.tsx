import axios from 'axios';
import { book } from './book'
import React, { Component } from 'react'

export class bookManager {
    getAllBooks(dispatch: any) {
        axios.get("http://localhost:9000/api/books")
            .then((res) => {
                dispatch({ type: "LIST", books: res.data })
            })
            .catch((err) => {
                console.log(err.message)
            })
    }
    addBooks = async (dispatch: any, book: any, token: any) => {
        let check = await axios.post("http://localhost:9000/api/books/add", book, {
            headers: {
                "Authorization": token,
                "Content-Type": "application/json"
            }
        })
        if (check.status === 200) {
            console.log("add")
            dispatch({ type: "ADDBOOK", book: book })
        } else {
            console.log(Error);
        }
    }
    loggingIn = async (username: string, password: string) => {
        let data = await fetch(`http://localhost:9000/api/users/login`, {
            method: "POST",
            body: JSON.stringify({ username: username, password: password }),
            headers: { "Content-Type": "application/json" }
        }
        )
        return data
    }
    loggingInWIthOtp = async (username: string, password: string, otp: string) => {
        let data = await fetch(`http://localhost:9000/api/users/otpverifying`, {
            method: "POST",
            body: JSON.stringify({ username: username, password: password, otp: otp }),
            headers: { "Content-Type": "application/json" }
        })
        return data
    }
    deleteBook = async (dispatch: any, id: any) => {
        let token = "Bearer " + localStorage.getItem("token");
        let check = await axios.delete("http://localhost:9000/api/books/" + id, {
            headers: {
                "Authorization": token,
                "Content-Type": "application/json"
            }
        })
        if (check.status === 200) {
            dispatch({ type: "DELETE", deleteBook: id })
        } else {
            console.log(Error);
        }
    }
    render() {
        return (
            <div>

            </div>
        )
    }
}

export default bookManager
