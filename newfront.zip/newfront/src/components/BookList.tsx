import { Link } from 'react-router-dom';
import React, { useContext, useEffect } from 'react'
import { book } from './book';
import OneBook from './OneBook';
import Searching from './Search';
import UserContext from './UserContext';
import { bookManager } from './bookManager'

interface booklistprops {
    list: book[]

}
let bmObj = new bookManager
const BookList: React.FC<booklistprops> = (props) => {
    const { booksArray, dispatch } = useContext(UserContext);
    const initialState = useContext(UserContext)

    useEffect(() => {
        bmObj.getAllBooks(dispatch);
    }, [])
    // console.log("books ...")
    // console.log(booksArray)
    let book = initialState.booksArray.books.map((book: any, index: any) => {
        return (
            <div>
                <Link to={`/${book._id}`}>
                    <OneBook book={book}></OneBook>

                </Link>
            </div>
        )

    })
    return (
        <>
            <div>
                <Searching list={props.list}></Searching>
            </div>
            <div>
                {book}
            </div>
        </>
    )
}

export default BookList

