export class user{
    username:string;
    password:string;
    phonenumber:string;
    address:string;
   id:string
constructor(username:string,password:string,phonenumber:string,
    address:string,
    id:any){
    this.username=username;
    this.password=password;
    this.phonenumber=phonenumber;
    this.address=address;
    this.id=id
   
}
}