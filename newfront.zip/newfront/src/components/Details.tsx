import react, { useContext } from 'react'
import { useParams, useHistory } from 'react-router'
// import { book } from './book'
import { Card, Button } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css'
import UserContext from './UserContext';
import Star from './Star';
import bookManager from './bookManager'
// import { Body } from 'react-bootstrap/lib/Media';
// import { FaAudioDescription } from 'react-icons/fa';

// interface Iprops {
//     // list:book[],
//     // delete: (_id:any) => void
//     userCheck: boolean
// }
// let {booksArray}=useContext(UserContext)
const Details = (props: any) => {
    const { _id }: any = useParams();
    const history = useHistory();
    const bmObj = new bookManager;
    const { booksArray, dispatch } = useContext(UserContext);
    // const initialState =useContext(UserContext)
    let detailbook = booksArray.books.map((book: any, index) => {
        if (book._id === _id) {
            // console.log("if")
            return (
                <div style={{ fontFamily: "Times New Roman", padding: "20px" }}>
                    <h1 style={{ textAlign: "center" }}><strong>{book.title}</strong></h1><hr /><br />
                    <div className="container">
                        <div className="row">
                            <div className="col-3">
                                <img className="card-img-top  mh-50 w-1 shadow p-1 mb-3 bg-white rounded" style={{ "float": "left" }} src={book.cover}></img>
                            </div>
                            <div className="col-6">
                                <p style={{ textAlign: "center", fontSize: "20px" }}><strong>Description:</strong>
                                    <p style={{ lineHeight: "25px", textAlign: "justify" }}>{book.body}</p></p>
                                {localStorage.getItem("login") ? <Button variant="danger" onClick={() => { bmObj.deleteBook(dispatch, _id); history.push("/") }}>Delete</Button> : null}
                            </div>
                            <div className="col-2">
                                <Card className="box h-199 w-12 align-right shadow p-3 mb-5 bg-white rounded ">
                                    <div className="card" style={{ width: "18rem", height: "50rem" }}>
                                        <ul className="list-group list-group-flush">
                                            <li className="list-group-item" style={{ width: "17rem", height: "6rem", textAlign: "center", padding: "2rem 1rem" }}><h4><strong>Title:</strong>{book.title}</h4></li>
                                            <li className="list-group-item" style={{ width: "17rem", height: "6rem", textAlign: "center", padding: "2rem 1rem" }}><h4><strong>Author:</strong>{book.author}</h4></li>
                                            <li className="list-group-item" style={{ width: "17rem", height: "5rem", textAlign: "center", padding: "2rem 1rem" }}><h4><strong>Price:</strong>{book.price}</h4></li>
                                            <li className="list-group-item" style={{ width: "17rem", height: "5rem", textAlign: "center", padding: "2rem 1rem" }}><h4><strong>Rating:</strong></h4><Star value={book.rating}></Star></li>
                                        </ul>
                                    </div>
                                </Card>
                            </div>
                        </div>
                    </div>
                </div>
            )
        }
    })
    return (
        <div>{detailbook}</div>
    )
}
export default Details