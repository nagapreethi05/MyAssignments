import React, { useReducer } from 'react'
import { book } from "./book"
import { user } from "./user"
import reducer from '../reducer'
interface Iusercontext {
    booksArray: {
        books: [],
        users: [],
        user: boolean,
        selectedbook: [],
        search: []
    }
    dispatch: React.Dispatch<any>
}
const initalState = {
    books: [],
    user: false,
    selectedbook: [],
    search: []
}

const UserContext = React.createContext<Iusercontext>({} as Iusercontext);
const UserProvider = (props: any) => {
    const [booksArray, dispatch] = useReducer(reducer, initalState, () => {
        return initalState;
    })
    return (
        <UserContext.Provider value={{ booksArray, dispatch }} >
            {props.children}
        </UserContext.Provider>
    )
}
const UserConsumer = UserContext.Consumer;
export { UserProvider, UserConsumer }
export default UserContext