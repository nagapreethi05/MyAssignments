"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteBook = exports.put = exports.addBook = exports.editBook = exports.getMatchingId = exports.getById = exports.getBooks = exports.booksRouter = void 0;
var express_1 = __importDefault(require("express"));
var books_schema_1 = __importDefault(require("../Model/books-schema"));
exports.booksRouter = express_1.default.Router();
var getBooks = function (req, res) { return __awaiter(void 0, void 0, void 0, function () {
    var author, title, minprice, maxprice, id, rating, price, books, err_1, books, err_2, books, err_3, books, err_4, books, err_5, books, err_6, books, err_7;
    return __generator(this, function (_a) {
        switch (_a.label) {
            case 0:
                author = req.query.author;
                title = req.query.title;
                minprice = req.query.minprice;
                maxprice = req.query.maxprice;
                id = req.query.id;
                rating = req.query.rating;
                price = req.query.price;
                console.log(title);
                if (!title) return [3 /*break*/, 5];
                _a.label = 1;
            case 1:
                _a.trys.push([1, 3, , 4]);
                return [4 /*yield*/, books_schema_1.default.find({ title: { $regex: new RegExp(title), $options: "i" } })];
            case 2:
                books = _a.sent();
                if (books) {
                    return [2 /*return*/, res.status(200).json(books)];
                }
                else {
                    return [2 /*return*/, res.status(404).json("title not found")];
                }
                return [3 /*break*/, 4];
            case 3:
                err_1 = _a.sent();
                res.send('Error ' + err_1);
                return [3 /*break*/, 4];
            case 4: return [3 /*break*/, 33];
            case 5:
                if (!author) return [3 /*break*/, 10];
                _a.label = 6;
            case 6:
                _a.trys.push([6, 8, , 9]);
                return [4 /*yield*/, books_schema_1.default.find({ author: { $regex: new RegExp(author), $options: "i" } })];
            case 7:
                books = _a.sent();
                if (books) {
                    return [2 /*return*/, res.status(200).json(books)];
                }
                else {
                    return [2 /*return*/, res.status(404).json("author not found")];
                }
                return [3 /*break*/, 9];
            case 8:
                err_2 = _a.sent();
                res.send('Error ' + err_2);
                return [3 /*break*/, 9];
            case 9: return [3 /*break*/, 33];
            case 10:
                if (!rating) return [3 /*break*/, 15];
                _a.label = 11;
            case 11:
                _a.trys.push([11, 13, , 14]);
                return [4 /*yield*/, books_schema_1.default.find({ rating: rating })];
            case 12:
                books = _a.sent();
                if (books) {
                    return [2 /*return*/, res.status(200).json(books)];
                }
                else {
                    return [2 /*return*/, res.status(404).json("rating not found")];
                }
                return [3 /*break*/, 14];
            case 13:
                err_3 = _a.sent();
                res.send('Error ' + err_3);
                return [3 /*break*/, 14];
            case 14: return [3 /*break*/, 33];
            case 15:
                if (!id) return [3 /*break*/, 20];
                _a.label = 16;
            case 16:
                _a.trys.push([16, 18, , 19]);
                return [4 /*yield*/, books_schema_1.default.find({ id: id })];
            case 17:
                books = _a.sent();
                if (books) {
                    return [2 /*return*/, res.status(200).json(books)];
                }
                else {
                    return [2 /*return*/, res.status(404).json("id not found")];
                }
                return [3 /*break*/, 19];
            case 18:
                err_4 = _a.sent();
                res.send('Error ' + err_4);
                return [3 /*break*/, 19];
            case 19: return [3 /*break*/, 33];
            case 20:
                if (!price) return [3 /*break*/, 25];
                _a.label = 21;
            case 21:
                _a.trys.push([21, 23, , 24]);
                return [4 /*yield*/, books_schema_1.default.find({ price: price })];
            case 22:
                books = _a.sent();
                if (books) {
                    return [2 /*return*/, res.status(200).json(books)];
                }
                else {
                    return [2 /*return*/, res.status(404).json("id not found")];
                }
                return [3 /*break*/, 24];
            case 23:
                err_5 = _a.sent();
                res.send('Error ' + err_5);
                return [3 /*break*/, 24];
            case 24: return [3 /*break*/, 33];
            case 25:
                if (!(minprice && maxprice)) return [3 /*break*/, 30];
                _a.label = 26;
            case 26:
                _a.trys.push([26, 28, , 29]);
                return [4 /*yield*/, books_schema_1.default.find({
                        $and: [{ price: { $gte: minprice } }, { price: { $lte: maxprice } }],
                    })];
            case 27:
                books = _a.sent();
                res.json(books);
                return [3 /*break*/, 29];
            case 28:
                err_6 = _a.sent();
                res.send("Error" + err_6);
                return [3 /*break*/, 29];
            case 29: return [3 /*break*/, 33];
            case 30:
                _a.trys.push([30, 32, , 33]);
                return [4 /*yield*/, books_schema_1.default.find()];
            case 31:
                books = _a.sent();
                res.json(books);
                return [3 /*break*/, 33];
            case 32:
                err_7 = _a.sent();
                res.send("Error " + err_7);
                return [3 /*break*/, 33];
            case 33: return [2 /*return*/];
        }
    });
}); };
exports.getBooks = getBooks;
//search by id
var getById = function (req, res) { return __awaiter(void 0, void 0, void 0, function () {
    var books, err_8;
    return __generator(this, function (_a) {
        switch (_a.label) {
            case 0:
                _a.trys.push([0, 2, , 3]);
                return [4 /*yield*/, books_schema_1.default.findById(req.params.id)];
            case 1:
                books = _a.sent();
                if (books) {
                    res.status(200).json(books);
                }
                else {
                    res.status(404).json("id not found");
                }
                return [3 /*break*/, 3];
            case 2:
                err_8 = _a.sent();
                res.send("error" + err_8);
                return [3 /*break*/, 3];
            case 3: return [2 /*return*/];
        }
    });
}); };
exports.getById = getById;
var getMatchingId = function (req, res) { return __awaiter(void 0, void 0, void 0, function () {
    var search, books, err_9;
    return __generator(this, function (_a) {
        switch (_a.label) {
            case 0:
                search = req.params.id;
                _a.label = 1;
            case 1:
                _a.trys.push([1, 3, , 4]);
                return [4 /*yield*/, books_schema_1.default.find({ title: search })];
            case 2:
                books = _a.sent();
                res.json(books);
                if (books) {
                    res.status(200).json(books);
                }
                else {
                    res.status(404);
                }
                return [3 /*break*/, 4];
            case 3:
                err_9 = _a.sent();
                res.send("error" + err_9);
                return [3 /*break*/, 4];
            case 4: return [2 /*return*/];
        }
    });
}); };
exports.getMatchingId = getMatchingId;
var editBook = function (req, res) { return __awaiter(void 0, void 0, void 0, function () {
    var title, author, price, rating, body, books, err_10;
    return __generator(this, function (_a) {
        switch (_a.label) {
            case 0:
                _a.trys.push([0, 12, , 13]);
                title = req.body.title;
                if (!title) return [3 /*break*/, 2];
                return [4 /*yield*/, books_schema_1.default.updateOne({ "_id": req.params.id }, { $set: { "title": title } })];
            case 1:
                _a.sent();
                _a.label = 2;
            case 2:
                author = req.body.author;
                if (!author) return [3 /*break*/, 4];
                return [4 /*yield*/, books_schema_1.default.updateOne({ "_id": req.params.id }, { $set: { "author": author } })];
            case 3:
                _a.sent();
                _a.label = 4;
            case 4:
                price = req.body.price;
                if (!price) return [3 /*break*/, 6];
                return [4 /*yield*/, books_schema_1.default.updateOne({ "_id": req.params.id }, { $set: { "price": price } })];
            case 5:
                _a.sent();
                _a.label = 6;
            case 6:
                rating = req.body.rating;
                if (!rating) return [3 /*break*/, 8];
                return [4 /*yield*/, books_schema_1.default.updateOne({ "_id": req.params.id }, { $set: { "rating": rating } })];
            case 7:
                _a.sent();
                _a.label = 8;
            case 8:
                body = req.body.body;
                if (!body) return [3 /*break*/, 10];
                return [4 /*yield*/, books_schema_1.default.updateOne({ "_id": req.params.id }, { $set: { "body": body } })];
            case 9:
                _a.sent();
                _a.label = 10;
            case 10: return [4 /*yield*/, books_schema_1.default.findbyId(req.params.id)];
            case 11:
                books = _a.sent();
                if (books) {
                    res.status(200).json(books);
                }
                else {
                    res.status(404).send("Id not found");
                }
                return [3 /*break*/, 13];
            case 12:
                err_10 = _a.sent();
                res.send(err_10);
                return [3 /*break*/, 13];
            case 13: return [2 /*return*/];
        }
    });
}); };
exports.editBook = editBook;
var addBook = function (req, res) { return __awaiter(void 0, void 0, void 0, function () {
    var books, a1, err_11;
    return __generator(this, function (_a) {
        switch (_a.label) {
            case 0:
                books = new books_schema_1.default({
                    title: req.body.title,
                    author: req.body.author,
                    price: req.body.price,
                    rating: req.body.rating,
                    pages: req.body.pages,
                    body: req.body.body,
                    cover: req.body.cover
                });
                _a.label = 1;
            case 1:
                _a.trys.push([1, 3, , 4]);
                return [4 /*yield*/, books.save()];
            case 2:
                a1 = _a.sent();
                if (a1) {
                    res.status(201).json(a1);
                }
                else {
                    res.sendStatus(400);
                }
                return [3 /*break*/, 4];
            case 3:
                err_11 = _a.sent();
                res.send('Error...!');
                return [3 /*break*/, 4];
            case 4: return [2 /*return*/];
        }
    });
}); };
exports.addBook = addBook;
var put = function (req, res) { return __awaiter(void 0, void 0, void 0, function () {
    var books, a1, err_12;
    return __generator(this, function (_a) {
        switch (_a.label) {
            case 0:
                _a.trys.push([0, 3, , 4]);
                return [4 /*yield*/, books_schema_1.default.findById(req.params.id)];
            case 1:
                books = _a.sent();
                books.title = req.body.title,
                    books.author = req.body.author,
                    books.price = req.body.price,
                    books.rating = req.body.rating,
                    books.pages = req.body.pages;
                return [4 /*yield*/, books.save()];
            case 2:
                a1 = _a.sent();
                if (books) {
                    res.status(202).json(a1);
                }
                else {
                    res.status(404).send("id not found");
                }
                return [3 /*break*/, 4];
            case 3:
                err_12 = _a.sent();
                res.send('Error id' + err_12);
                return [3 /*break*/, 4];
            case 4: return [2 /*return*/];
        }
    });
}); };
exports.put = put;
var deleteBook = function (req, res) { return __awaiter(void 0, void 0, void 0, function () {
    var books, err_13;
    return __generator(this, function (_a) {
        switch (_a.label) {
            case 0:
                _a.trys.push([0, 5, , 6]);
                return [4 /*yield*/, books_schema_1.default.findById(req.params.id)];
            case 1:
                books = _a.sent();
                if (!books) return [3 /*break*/, 3];
                return [4 /*yield*/, books.remove()];
            case 2:
                _a.sent();
                res.send("Book Deleted");
                return [3 /*break*/, 4];
            case 3:
                res.status(404).send("Id Not Found");
                _a.label = 4;
            case 4: return [3 /*break*/, 6];
            case 5:
                err_13 = _a.sent();
                res.send('Error' + err_13);
                return [3 /*break*/, 6];
            case 6: return [2 /*return*/];
        }
    });
}); };
exports.deleteBook = deleteBook;
