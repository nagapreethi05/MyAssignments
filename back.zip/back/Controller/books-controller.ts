import express from 'express';
import Books from '../Model/books-schema';
import { authenticate } from './users-controller'
export const booksRouter = express.Router()

export const getBooks=async (req: any, res: any) => {
    let author = req.query.author;
    let title = req.query.title;
    let minprice = req.query.minprice;
    let maxprice = req.query.maxprice;
    let id = req.query.id;
    let rating = req.query.rating;
        let price = req.query.price;
    console.log(title)
    if (title) {
        try {
            const books = await Books.find({ title: {$regex:new RegExp(title) ,$options:"i"}});
            if (books) {
                return res.status(200).json(books);
            } else {
                return res.status(404).json("title not found");
            }
        } catch (err) {
            res.send('Error ' + err)
        }
    }
    else if (author) {

        try {
            const books = await Books.find({ author:  {$regex:new RegExp(author),$options:"i"}});
            if (books) {
                return res.status(200).json(books);
            } else {
                return res.status(404).json("author not found");
            }

        } catch (err) {
            res.send('Error ' + err)
        }
    }
    else if (rating) {

        try {
            const books = await Books.find({ rating:  rating});
            if (books) {
                return res.status(200).json(books);
            } else {
                return res.status(404).json("rating not found");
            }

        } catch (err) {
            res.send('Error ' + err)
        }
    }
    else if (id) {

        try {
            const books = await Books.find({ id:id });
            if (books) {
                return res.status(200).json(books);
            } else {
                return res.status(404).json("id not found");
            }

        } catch (err) {
            res.send('Error ' + err)
        }
    }
    else if (price) {

        try {
            const books = await Books.find({ price:price });
            if (books) {
                return res.status(200).json(books);
            } else {
                return res.status(404).json("id not found");
            }

        } catch (err) {
            res.send('Error ' + err)
        }
    }
    else if (minprice && maxprice) {
        try {
            const books: any = await Books.find({
                $and: [{ price: { $gte: minprice } }, { price: { $lte: maxprice } }],

            });
            res.json(books);
        } catch (err) {
            res.send("Error" + err);
        }
    }

    else {
        try {
            const books = await Books.find();
            res.json(books);
        }
        catch (err) {
            res.send("Error " + err);
        }
    }
};
//search by id
export const getById= async (req: any, res: any) => {
    try {
        const books: any = await Books.findById(req.params.id);
        if (books) {
            res.status(200).json(books);
        }
        else {
            res.status(404).json("id not found");
        }
    } catch (err) {
        res.send("error" + err);
    }
};
 export const getMatchingId=async (req: any, res: any) => {
    let search: any = req.params.id;
    try {
        const books: any = await Books.find({ title: search });
        res.json(books);
        if (books) {
            res.status(200).json(books);
        } else {
            res.status(404);
        }
    } catch (err) {
        res.send("error" + err);
    }
};
export const editBook= async (req: any, res: any) => {
    try {
        let title = req.body.title;
        if (title) {
            await Books.updateOne({ "_id": req.params.id }, { $set: { "title": title } });
        }
        let author = req.body.author;
        if (author) {
            await Books.updateOne({ "_id": req.params.id }, { $set: { "author": author } });
        }
        let price = req.body.price;
        if (price) {
            await Books.updateOne({ "_id": req.params.id }, { $set: { "price": price } });
        }
        let rating = req.body.rating;
        if (rating) {
            await Books.updateOne({ "_id": req.params.id }, { $set: { "rating": rating } });
        }
        let body = req.body.body;
        if (body) {
            await Books.updateOne({ "_id": req.params.id }, { $set: { "body": body } });
        }
        const books = await Books.findbyId(req.params.id);
        if (books) {
            res.status(200).json(books);
        } else {
            res.status(404).send("Id not found");
        }

    } catch (err: any) {
        res.send(err);
    }
}
 export const addBook=async (req: any, res: any) => {
    const books = new Books({
        title: req.body.title,
        author: req.body.author,
        price: req.body.price,
        rating: req.body.rating,
        pages: req.body.pages,
        body: req.body.body,
        cover: req.body.cover
    })
    try {
 
        const a1 = await books.save();
        if (a1) {
            res.status(201).json(a1);
        }
        else {
            res.sendStatus(400);
        }
    } catch (err) {
        res.send('Error...!')
    }
}

export const put=async (req: any, res: any) => {
    try {
        const books = await Books.findById(req.params.id)
        books.title = req.body.title,
            books.author = req.body.author,
            books.price = req.body.price,
            books.rating = req.body.rating,
            books.pages = req.body.pages
        const a1 = await books.save();
        if (books) {
            res.status(202).json(a1);
        } else {
            res.status(404).send("id not found")
        }

    } catch (err) {
        res.send('Error id' + err)
    }

}
export const deleteBook= async (req: any, res: any) => {
    try {
        const books = await Books.findById(req.params.id)
        if (books) {
            await books.remove();
            res.send("Book Deleted");
        } else {
            res.status(404).send("Id Not Found")
        }


    } catch (err) {
        res.send('Error' + err)
    }
}
