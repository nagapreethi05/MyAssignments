const mongoosee = require('mongoose')
const bookSchema = new mongoosee.Schema({
    title: {
        type: String,
    },
    author: {
        type: String,
    },
    price: {
        type: String
    },
    rating: {
        type: String
    },
    pages: {
        type: String
    },
    body: {
        type: String
    },
    cover: {
        type: String
    }

},
    { collection: "books" }
)
export = mongoosee.model('book', bookSchema)
