"use strict";
var mongoosee = require('mongoose');
var bookSchema = new mongoosee.Schema({
    title: {
        type: String,
    },
    author: {
        type: String,
    },
    price: {
        type: String
    },
    rating: {
        type: String
    },
    pages: {
        type: String
    },
    body: {
        type: String
    },
    cover: {
        type: String
    }
}, { collection: "books" });
module.exports = mongoosee.model('book', bookSchema);
