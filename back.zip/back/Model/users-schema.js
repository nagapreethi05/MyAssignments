"use strict";
var mongoosee = require("mongoose");
var userSchema = new mongoosee.Schema({
    username: {
        type: String,
        required: [true, "please enter an email"],
        unique: true,
        lowercase: true,
    },
    password: {
        type: String,
        required: [true, "please enter password"],
        minLength: [6, "enter minimum 6 chars"],
    },
    phonenumber: {
        type: String,
        required: false,
    },
    address: {
        type: String,
        required: false,
    },
    otp: {
        type: String,
        required: false,
    },
    time: {
        type: String,
        required: false,
    },
}, { collection: "Authentication" });
module.exports = mongoosee.model("User", userSchema);
