"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var express_1 = __importDefault(require("express"));
var books_controller_1 = require("../Controller/books-controller");
var users_controller_1 = require("../Controller/users-controller");
var booksRouter = express_1.default.Router();
booksRouter.get('/', books_controller_1.getBooks);
booksRouter.get("/:id", books_controller_1.getById);
booksRouter.get("/matching/:id", books_controller_1.getMatchingId);
booksRouter.patch('/:id', users_controller_1.authenticate, books_controller_1.editBook);
booksRouter.post('/add', users_controller_1.authenticate, books_controller_1.addBook);
booksRouter.put('/:id', users_controller_1.authenticate, books_controller_1.put);
booksRouter.delete('/:id', users_controller_1.authenticate, books_controller_1.deleteBook);
exports.default = booksRouter;
