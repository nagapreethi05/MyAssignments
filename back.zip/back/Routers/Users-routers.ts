import express from "express";
import User from "../Model/users-schema";
import {
  authenticate,
  userlogin,
  otpverify,
  getuser,
  registration,
} from "../Controller/users-controller";
const usersRouter = express.Router();

usersRouter.post("/login", userlogin);
usersRouter.post("/otpverifying", otpverify);
usersRouter.get("/", getuser);
usersRouter.post("/registration", registration);
export default usersRouter;
