import express from "express";
import {getBooks,getById,getMatchingId,editBook,addBook,put,deleteBook} from '../Controller/books-controller'
import {authenticate, userlogin,otpverify,getuser,registration} from '../Controller/users-controller';
const booksRouter=express.Router();

booksRouter.get('/',getBooks);
booksRouter.get("/:id",getById);
booksRouter.get("/matching/:id",getMatchingId);
booksRouter.patch('/:id', authenticate,editBook);
booksRouter.post('/add',authenticate,addBook);
booksRouter.put('/:id', authenticate, put);
booksRouter.delete('/:id',authenticate,deleteBook);


export default booksRouter;