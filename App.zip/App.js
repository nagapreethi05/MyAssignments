import logo from './logo.svg';
import './App.css';
import ClickCounter from './components/ClickCounter'
import HoverCounter from './components/HoverCounter'
import React, { Component } from 'react'

class App extends Component {
  render() {
    return (
      <div classname="App">
        <ClickCounter></ClickCounter>
        <HoverCounter></HoverCounter>
      </div>
    )
  }
}

export default App


